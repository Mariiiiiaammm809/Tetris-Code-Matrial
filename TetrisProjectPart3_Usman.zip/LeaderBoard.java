/*
 * CSCI 282 - LeaderBoard class: Handles everything relating to the leaderBoard
 * Mariam Usman
 * 01/09/23
 */
import java.util.*;
import java.io.*;
import javax.swing.*;


class Score implements Comparable<Score>              //player's name and score encapsulated
{
    private String playerName;
    private int score;

    public Score(String playerName, int score)
    {
        this.playerName = playerName;
        this.score = score;
    }
    
    @Override
    public int compareTo(Score initialScore) {
        
        return Integer.compare(initialScore.getScore(), this.score);
    }

public class LeaderBoard {
    String fileName = "Score.dat";
    
    public static String scoreSorter(ArrayList<String> scores) 
    {
        int maxNum =10;
        ArrayList<Score> scoreList = new ArrayList<>();  
        for (int index = 0; index < scores.size(); index++) 
        {
            String score = scores.get(index);
            Scanner scanner = new Scanner(score);
            scanner.useDelimiter(": ");
            if (scanner.hasNext()) 
            {
                String playerName = scanner.next();
                if (scanner.hasNextInt())
                {
                    int playerScore = scanner.nextInt();
                    scoreList.add(new Score(playerName, playerScore));
                }
            }
            scanner.close();
            if (scoreList.size() >= maxNum) {
                break;
            }
        }

        Collections.sort(scoreList); //Collection class 
        String newScores = "";
        int number = 1;
        for (int index = 0; index < scoreList.size(); index++)
        {
            Score score = scoreList.get(index);
            newScores += number + ". " + score.getPlayerName() + ": " + score.getScore() + "\n";
            number++;
        }
        return newScores;
    }


    public void recordScore(String playerName, int score)
    {   int maxNum =10;
        ArrayList<String> currentScores = getCurrentScores();
    
        if (currentScores.size() >= maxNum) {
            int lowestScore = getLowestScore(currentScores);
            if (score > lowestScore) {
                currentScores.remove(maxNum);
                currentScores.add(playerName + ": " + score);
            }
        }
        else 
        {
            currentScores.add(playerName + ": " + score);
        
        }

        File fileConnection = new File(fileName);
        if (fileConnection.exists() && !fileConnection.canWrite())
        {
            String errorMessage = "An error has occurred writing to file.";
            JOptionPane.showMessageDialog(null, errorMessage, "Error!", 0);
            return;
        }
        try 
        {
          FileWriter outWriter = new FileWriter(fileConnection, true);
            outWriter.write(playerName + ": " + score + "\n");
            outWriter.close();  
        } 
        catch (IOException ioe) 
        {
            String errorMessage = "An error has occurred writing to file: score";
            JOptionPane.showMessageDialog(null, errorMessage, "Error!", 0);
        }
    }

    public String getScoreBoard()  //gets the current score from board
    {
        ArrayList<String> initialScores = getCurrentScores();
        return scoreSorter(initialScores);
    }

    public void clearScore()
    {
        try 
        {
            FileWriter file = new FileWriter(fileName, false);
            PrintWriter flusher = new PrintWriter(file, false);
            flusher.flush();
            flusher.close();
            file.close();
        } 
        catch (IOException e) 
        {
            String errorMessage = "Trouble opening selected file";
            JOptionPane.showMessageDialog(null, errorMessage, "Error!", 0);
        }
    }

    public ArrayList<String> getCurrentScores()  //reads the scores from file
    {
        ArrayList<String> currentScores = new ArrayList<>();
        try
        {
            File file = new File(fileName);
            Scanner inScan = new Scanner(file);
            while (inScan.hasNextLine()) 
            {
                currentScores.add(inScan.nextLine());
            }
            inScan.close();
        } 
        catch (FileNotFoundException e) 
        {
            String errorMessage = "Trouble opening selected file";
            JOptionPane.showMessageDialog(null, errorMessage, "Error!", 0);
        }
        return currentScores;
    }

    public int getLowestScore(ArrayList<String> scores) 
    {
        if (scores.size()==0) 
        {
            return 0;
        }

        ArrayList<Integer> playerScore = new ArrayList<>();
        for (int index = 0; index < scores.size(); index++) {
            String score = scores.get(index);
            Scanner scanner = new Scanner(score);
            scanner.useDelimiter(": ");

            if (scanner.hasNext()) 
            { 
                scanner.next(); 
            }

            if (scanner.hasNextInt())
            { 
                playerScore.add(scanner.nextInt());
            }

             scanner.close();
        }
        return Collections.min(playerScore);  //collections class.
    }
     
    @Override
    public String toString() 
    {
        String result = "";
    
        ArrayList<String> currentScores = getCurrentScores();
        for (String score : currentScores)
        {
            result += score + "\n";
        }
    
     return result;
    }
}
    public String getPlayerName()
    {
        return playerName;
    }

    public int getScore() 
    {
        return score;
    }
    
}